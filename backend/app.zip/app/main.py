from fastapi import FastAPI

from app.api.products import router as products_router
from app.database import Base, engine
import app.models


Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Sistema Supermercado",
    version="0.1.0",
)

app.include_router(products_router)


@app.get("/")
def root() -> dict[str, str]:
    return {
        "message": "API del supermercado funcionando",
    }